"""Reproduce a native read-only continuation for a locked, real first-draw status lookup."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.request
from datetime import datetime,timedelta,timezone

from projection import runone,sha,read,src,run,root
from runtime.executor import provider_key

def now():
    return datetime.now(timezone.utc)

def put(path,document):
    path.write_text(json.dumps(document,ensure_ascii=False,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task',choices=['62d6b8d8','ac20b007','213cfacb'])
    task=parser.parse_args().task
    branch=run/'branches'/task
    destination=branch/'resume'
    original=read(run/(task+'.meta.json'))
    first=(run/(task+'.response.json')).read_bytes()
    initial=json.loads(first)
    budget=read(branch/'budget.json')
    assert budget['reason'] is None and budget['available_generation']==2048
    actor=json.loads(initial['choices'][0]['message']['tool_calls'][0]['function']['arguments'])['input_json']['drone_id']
    row=next(r for r in read(src/'audit/closing-repair-review.json')['tasks'] if r['task_id']==task)
    scene=row['scene_id']
    source=next((root/'datasets/results/benchmark-600/raw').glob('*/'+scene+'/'+task+'.after.json'))
    chain=src/'raw'/scene/'agent-traces'/'toolchains'/row['source_toolchain']
    archive=chain.parent.parent/'modelio'/Path(read(chain)['model_io_archive']['path']).name
    barrier=source.with_name(task+'.barrier.json')
    barrier_data=read(barrier)
    assert barrier_data['simulation_paused'] and barrier_data['quiescent'] and not barrier_data['inflight']
    first_ledger=read(branch/'meta.json')
    assert first_ledger['status']=='original_deadline_elapsed_before_verification'
    invoke_key=provider_key()
    assert invoke_key and invoke_key!='<redacted>'
    budget_wall=original['remaining_seconds']-original['elapsed_seconds']
    remaining_at_launch=budget_wall
    start=now();mono=time.monotonic()
    deadline=start+timedelta(seconds=remaining_at_launch)
    destination.mkdir(exist_ok=False)
    fresh=destination/'simulator';fresh.mkdir()
    log=(fresh/'process.log').open('w')
    args=[str(root/'simulation/server/.venv/bin/python'),str(Path(__file__).with_name('sim.py')),str(fresh),str(source),actor]
    endpoint=original['endpoint']
    assert endpoint=='https://api.deepseek.com/chat/completions'
    proc=subprocess.Popen(args,stdout=log,stderr=log,env={**os.environ,'PYTHONPATH':str(root),'REPRO_SERVER_LOG_DIR':str(fresh/'logs')})
    try:
        while not (fresh/'port').exists():
            if proc.poll() is not None:raise RuntimeError('Isolated simulator restoration failed')
            if time.monotonic()-mono>=remaining_at_launch:raise TimeoutError('Original budget exhausted during restoration')
            time.sleep(.015)
        raw=runone(row,resume=destination,port=(fresh/'port').read_text())
        qwen_sha=sha(raw);assert qwen_sha==budget['request_sha256']
        (destination/'request.json').write_bytes(raw)
        sent=now();smon=time.monotonic()
        remaining=remaining_at_launch-(smon-mono)
        assert remaining>0
        restored=read(destination/'public-tool-receipt.json')
        rawget=restored['actual_api_calls']
        assert len(rawget)==1 and rawget[0]['method']=='GET' and rawget[0]['success'] and rawget[0]['endpoint']=='/drones/'+actor
        state=json.loads(restored['messages'][-1]['content'])
        last=next(e['payload'] for e in reversed(read(chain)['task_progress']['events']) if e['tool_name']=='hover')
        assert last['drone_id']==actor and 0<=last['timestamp']-state['last_updated']<.001
        meta={'task_id':task,'scene_id':scene,'turn':original['turn']+1,'attempt':'independent_checkpoint_recovery_locked_first_draw','first_window_status':first_ledger['status'],'parent_request_sha256':original['original_request_sha256'],'parent_response_sha256':sha(first),'request_sha256':qwen_sha,'endpoint':endpoint,'attempt_started_at':start.isoformat(),'deadline_at':deadline.isoformat(),'original_prefix_elapsed_seconds':500-original['remaining_seconds'],'locked_model_elapsed_seconds':original['elapsed_seconds'],'remaining_seconds_at_send':remaining,'sent_at':sent.isoformat(),'qwen_budget':budget,'public_tool_receipt_sha256':sha((destination/'public-tool-receipt.json').read_bytes()),'snapshot_sha256':sha(source.read_bytes()),'snapshot_path':str(source.relative_to(root)),'barrier_sha256':sha(barrier.read_bytes()),'source_toolchain_sha256':sha(chain.read_bytes()),'source_modelio_sha256':sha(archive.read_bytes()),'hover_receipt_timestamp':last['timestamp'],'actor_last_updated':state['last_updated'],'actor_id':actor,'locked_tool_call_id':restored['messages'][-1]['tool_call_id'],'status':'dispatching'}
        put(destination/'meta.json',meta)
        request=urllib.request.Request(endpoint,data=raw,headers={'Authorization':'Bearer '+invoke_key,'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(request,timeout=remaining) as http:
            body=http.read();status=http.status
            done=now();emon=time.monotonic()
            (destination/'response.json').write_bytes(body)
        v=json.loads(body)
        u=v['choices'][0]
        meta.update(http_status=status,response_sha256=sha(body),model=v['model'],fingerprint=v.get('system_fingerprint'),response_id=v['id'],finish=u['finish_reason'],usage=v['usage'],elapsed_seconds=emon-smon,returned_at=done.isoformat(),total_attempt_elapsed_seconds=emon-mono,original_budget_total_elapsed_seconds=500-remaining_at_launch+emon-mono,status='response_received')
        put(destination/'meta.json',meta)
        assert emon-mono<=remaining_at_launch and done<=deadline and v['model']==original['model'] and v.get('system_fingerprint')==original['original_fingerprint'] and status==200
        print(task,meta['finish'],meta['elapsed_seconds'],meta['fingerprint'],flush=True)
    finally:
        proc.terminate();proc.wait(timeout=15);log.close()

if __name__=='__main__':main()
