from pathlib import Path
import json,subprocess,os
o=Path('/tmp/flockcue-ending-branches');p=Path('../MultiUAV-Plat-runs/teacher-endings-20261112');root=next(Path('datasets/results/benchmark-600/raw').glob('*/')); 
for tid in ('62d6b8d8','ac20b007','213cfacb'):
 f=o/tid
 if (f/'port').exists():continue
 r=json.load((p/f'{tid}.response.json').open());actor=json.loads(r['choices'][0]['message']['tool_calls'][0]['function']['arguments'])['input_json']['drone_id'];s=json.load((p/f'{tid}.meta.json').open())['scene_id'];log=(f/'sim.log').open('a');pr=subprocess.Popen(['simulation/server/.venv/bin/python',str(o/'sim.py'),str(f),str(root/s/f'{tid}.after.json'),actor],env={**os.environ,'REPRO_SERVER_LOG_DIR':str(f/'logs'),'PYTHONPATH':str(Path.cwd())},stdout=log,stderr=log,start_new_session=True);(f/'pid').write_text(str(pr.pid))
