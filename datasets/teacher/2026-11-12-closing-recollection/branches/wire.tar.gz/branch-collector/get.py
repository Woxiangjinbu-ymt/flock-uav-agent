import json,os
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime,timezone
from flockcue.tools.client import UAVAPIClient
from flockcue.tools.catalog import create_uav_tools
from flockcue.tools.inputs import adapt_input_json_tools
from flockcue.service import DeploymentDeepSeek
from flockcue.profile import environment,load_profile
os.environ.update(environment(load_profile()))
r=Path('../MultiUAV-Plat-runs/teacher-endings-20261112')
for t in ('62d6b8d8','ac20b007','213cfacb'):
 p=Path('/tmp/flockcue-ending-branches')/t;client=UAVAPIClient('http://127.0.0.1:'+ (p/'port').read_text())
 tools=adapt_input_json_tools(create_uav_tools(client),'json_object_or_string_v2')
 resp=json.loads((r/f'{t}.response.json').read_bytes())
 llm=DeploymentDeepSeek(model='deepseek-flash',temperature=.1,api_key='local')
 a=llm._create_chat_result(resp).generations[0].message
 c,=a.tool_calls
 m=next(k for k in tools if k.name==c['name']).invoke(c)
 assert m.tool_call_id==c['id'] and 'error' not in m.content.lower(),m.content
 (p/'receipt.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'messages':llm._get_request_payload([a,m])['messages']},ensure_ascii=False))
 print(t,m.tool_call_id,m.content[:125],flush=True)
