import json,os,sys,socket
from pathlib import Path
root=Path.cwd()
sys.path.insert(0,str(root/'simulation/server'))
from api import server
from models.session import Session
import uvicorn
folder, snapshot, actor = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
d=json.loads(snapshot.read_bytes())
model=Session.from_dict(d)
sc=server.session_controller
sc.sessions[model.id]=model
sc.set_current_session(model.id)
expected=next(a for a in d['drones'] if a['id']==actor)
import math
vehicle=server.drone_controller.drones[actor]
assert math.isclose(vehicle.battery_level, expected['battery_level'],rel_tol=0,abs_tol=2e-13)
vehicle.battery_level=expected['battery_level']
out=server.drone_controller.get_drone(actor)
assert all(out.get(k)==v for k,v in expected.items()), {k:[v,out.get(k)] for k,v in expected.items() if out.get(k)!=v}
sock=socket.socket();sock.bind(('127.0.0.1',0))
(folder/'port').write_text(str(sock.getsockname()[1]))
uvicorn.Server(uvicorn.Config(server.app,log_level='error',lifespan='off')).run(sockets=[sock])
