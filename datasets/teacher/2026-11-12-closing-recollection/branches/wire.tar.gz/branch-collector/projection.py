from dataclasses import dataclass,replace
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime,timezone
import hashlib,json,os,time
from flockcue.service import DeploymentDeepSeek
from flockcue.harness.integration import HarnessMiddleware
from flockcue.harness.core import HarnessRuntime,DecisionFrame
from flockcue.evidence.contacts import TaskEvidenceLedgerR2
from flockcue.tools.inputs import adapt_input_json_tools
from flockcue.tools.client import UAVAPIClient
from flockcue.tools.catalog import create_uav_tools
from flockcue.profile import environment,load_profile
from langchain_core.messages import AIMessage,SystemMessage,HumanMessage,ToolMessage
os.environ.update(environment(load_profile()))
root=Path.cwd()
read=lambda path:json.loads(path.read_bytes())
dump=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
sha=lambda x:hashlib.sha256(x).hexdigest()
src=root/'datasets/teacher/2026-11-11-fold-a'
run=root.parent/'MultiUAV-Plat-runs/teacher-endings-20261112'
base=Path('/tmp/flockcue-ending-branches')
@dataclass
class Req:
    system_message: object
    messages:list
    def override(self,**kwargs):return replace(self,**kwargs)
def runone(r, *, resume=None, port=None):
    t,s=r['task_id'],r['scene_id'];p=base/t
    reqbytes=(run/f'{t}.request.json').read_bytes();req=json.loads(reqbytes)
    rspbytes=(run/f'{t}.response.json').read_bytes();rsp=json.loads(rspbytes)
    original=src/'raw'/s/'agent-traces'
    c=read(original/'toolchains'/r['source_toolchain']);archive=original/'modelio'/Path(c['model_io_archive']['path']).name
    records=[json.loads(x) for x in archive.open()]
    inp=next(e['data']['input'] for e in records if e['kind']=='model_start' and e['data']['logical_call_id']=='model-'+str(r['terminal_turn']))
    msg=lambda x:{'system':SystemMessage,'ai':AIMessage,'human':HumanMessage,'tool':ToolMessage}[x['type']](**x)
    ledger=TaskEvidenceLedgerR2(c['command'],c['command_id'])
    ids={};events=c['task_progress']['events'];timeline=sorted([(e['start_sequence'],True,e) for e in events]+[(e['end_sequence'],False,e) for e in events])
    for _,start,e in timeline:
        if start:
            ids[e['evidence_id']]=ledger.begin_tool(e['tool_name'],e['args'],e['tool_call_id'])
            assert ids[e['evidence_id']]==e['evidence_id']
        else:
            ledger.end_tool(ids[e['evidence_id']],e['payload'])
    h=c['harness']
    harness=HarnessRuntime(task_id=h['task_id'],command=c['command'],scene_id=s,scene_epoch=h['scene_epoch'],ledger=ledger,invoke=None,skill_factory=None,scope=lambda:(s,h['scene_epoch']),started=time.monotonic(),scheduler=h['scheduler'],fixed_k=h['fixed_k'],revision=h['revision'],static_obstacle_contract=True)
    harness.frames={f['plan_id']:DecisionFrame(**f) for f in h['frames']}
    mw=HarnessMiddleware(ledger,harness);llm=DeploymentDeepSeek(model='deepseek-flash',api_key='offline',temperature=.1)
    orig=Req(msg(inp['system_message']),[msg(x) for x in inp['messages']])
    def render(request):
        v=mw._model_request(request)
        return llm._get_request_payload([v.system_message,*v.messages])['messages']
    reconstructed=render(orig)
    if reconstructed!=req['messages']:
        print('wire mismatches',[(i,str(j)[:45],str(k)[:45],j.keys(),k.keys()) for i,(j,k) in enumerate(zip(reconstructed,req['messages'])) if j!=k])
    assert reconstructed==req['messages']
    assert dump({**req,'messages':reconstructed})==reqbytes
    a=llm._create_chat_result(rsp).generations[0].message;call,=a.tool_calls
    client=UAVAPIClient('http://127.0.0.1:'+str(port or (p/'port').read_text()))
    client.start_api_call_recording()
    get_start=datetime.now(timezone.utc).isoformat()
    tool=next(x for x in adapt_input_json_tools(create_uav_tools(client),'json_object_or_string_v2') if x.name==call['name'])
    assert tool.name=='get_drone_status'
    receipt=mw.wrap_tool_call(SimpleNamespace(tool_call=call,state={'messages':[*orig.messages,a]}),lambda request:tool.invoke(call))
    assert receipt.tool_call_id==call['id']
    current=render(replace(orig,messages=[*orig.messages,a,receipt]))
    earlier=read(p/'receipt.json')
    assert current[:len(reconstructed)]==reconstructed and current[len(reconstructed):]==earlier['messages']
    expected=json.loads(receipt.content)
    if harness.frames:
        assert expected==next(iter(harness.frames.values())).state['last_verified_state']
    else:
        last=c['api_calls'][-1];assert last['method']=='POST' and last['endpoint']==f"/drones/{expected['id']}/command/hover"
        assert last['response']['command']=='hover'
        assert 0 <= c['task_progress']['events'][-1]['payload']['timestamp']-expected['last_updated'] < .001
        previous=c['api_calls'][-3]['response']
        assert previous['position']==expected['position']
    if resume is not None:
        wire=dump({**req,'messages':current})
        assert wire==(run/'branches'/t/'offline-candidate.request.json').read_bytes()
        receipt_log={'started_at':get_start,'returned_at':datetime.now(timezone.utc).isoformat(),'messages':current[-2:],'actual_api_calls':client.get_api_call_records()}
        (resume/'public-tool-receipt.json').write_text(json.dumps(receipt_log,ensure_ascii=False,indent=2)+'\n')
        return wire
    dst=run/'branches'/t;dst.mkdir(exist_ok=True,parents=True)
    meta=read(run/f'{t}.meta.json');deadline=datetime.fromisoformat(meta['sent_at']).timestamp()+meta['remaining_seconds']
    candidate=dump({**req,'messages':current})
    (dst/'offline-candidate.request.json').write_bytes(candidate)
    (dst/'public-tool-receipt.json').write_bytes((p/'receipt.json').read_bytes())
    record={'task_id':t,'scene_id':s,'parent_request_sha256':sha(reqbytes),'parent_response_sha256':sha(rspbytes),'reconstructed_parent_wire_match':True,'new_history_prefix_exact':True,'new_get_matches_first_restored_get':True,'new_get_matches_original_post_hover_public_state':bool(harness.frames),'logical_tool_call_id':call['id'],'original_deadline_utc':datetime.fromtimestamp(deadline,timezone.utc).isoformat(),'offline_verified_utc':datetime.now(timezone.utc).isoformat(),'status':'original_deadline_elapsed_before_verification','sent_to_provider':False,'wall_clock_extended':False,'offline_candidate_request_sha256':sha(candidate),'tool_receipt_sha256':sha((p/'receipt.json').read_bytes())}
    (dst/'meta.json').write_text(json.dumps(record,indent=2)+'\n')
    print(t,record['status'],flush=True)
if __name__=='__main__':
    for r in read(src/'audit/closing-repair-review.json')['tasks']:
        if r['task_id'] in ('62d6b8d8','ac20b007','213cfacb'):runone(r)
